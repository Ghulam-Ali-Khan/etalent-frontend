import React from 'react'

const Test = () => {
  return (
    <div>
      Ghulam Ali
    </div>
  )
}

export default Test
