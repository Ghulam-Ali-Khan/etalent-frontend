export const heroSeactionStackStyling = {
    height:'66vh',
    maxWidth:'800px',
    paddingTop:'5rem',
    justifyContent:'center',
    alignItems:'center'
};