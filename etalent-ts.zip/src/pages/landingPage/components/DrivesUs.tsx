import useGetPrimaryColor from '@/customHooks/useGetPrimaryColor';
import { Box, Container, Stack, Typography } from '@mui/material'
import React from 'react'

const DrivesUs = () => {
    return (
        <>
            <Container className='mt-[6rem]'>
                <Typography variant='h3' color='primary' textAlign={'center'} fontWeight={600}>
                    Drives Us
                </Typography>
            </Container>
        </>
    )
}

export default DrivesUs;

const DriveUsCard = () => {
    const primaryColor = useGetPrimaryColor();

    return (
        <Box padding={2} border={`1px solid ${primaryColor}`}>
            <Stack justifyContent={'space-between'} minHeight={'350px'}>

            </Stack>
        </Box>
    )
}
