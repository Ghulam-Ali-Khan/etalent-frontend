import { Business, Email, Groups, JoinLeft } from "@mui/icons-material";

export const kpisData = (primary: string) => [
  {
    count: 10,
    icon: <Email sx={{ color: primary, fontSize: "40px", mb: 2 }} />,
    title: "Job listings",
  },
  {
    count: 12,
    icon: <Business sx={{ color: primary, fontSize: "40px", mb: 2 }} />,
    title: "Freelance Projects",
  },
  {
    count: 5,
    icon: <Groups sx={{ color: primary, fontSize: "40px", mb: 2 }} />,
    title: "Sponsored Jobs",
  },
];


export const driveUsData = [
  {
    icon: <JoinLeft/>,
    title: 'Transparency',
    description: 'Honesty in every listing, no hidden feess',
  },
  {
    icon: null,
    title: 'User-Focused',
    description: 'Inclusive opportunities for everyone',
  },
  {
    icon: null,
    title: 'Diversity',
    description: 'Tailoring your search to your needs',
  },
  {
    icon: null,
    title: 'Quality',
    description: 'Only verified, quality job listings',
  }
]